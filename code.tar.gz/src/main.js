
const express = require("express");
const PORT=process.env.PORT || 3000;

const app = express();

// DynamoDB Configuration


// Middleware
app.use(express.json());

// Routes
app.get("/", (req, res) => {
  res.send({ message: "Welcome to the API!" });
});



// Reusable Sign-In Function


// Serverless Handler
app.listen(PORT, () => {
  console.log("Server running on port 3000");
});
